import random

class OthelloGame:
    def __init__(self):
        self.board = [['.' for _ in range(8)] for _ in range(8)]
        self.board[3][3] = 'W'
        self.board[3][4] = 'B'
        self.board[4][3] = 'B'
        self.board[4][4] = 'W'

    def display_board(self):
        print("   1 2 3 4 5 6 7 8")
        for i, row in enumerate(self.board, start=1):
            print(f"{i} | {' '.join(row)} |")
        print()

    def is_valid_move(self, row, col, player):
        if self.board[row][col] == '.':
            directions = [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (-1, -1), (1, -1), (-1, 1)]
            for dr, dc in directions:
                r, c = row + dr, col + dc
                if 0 <= r < 8 and 0 <= c < 8 and self.board[r][c] != '.' and self.board[r][c] != player:
                    while 0 <= r < 8 and 0 <= c < 8 and self.board[r][c] != '.':
                        if self.board[r][c] == player:
                            return True
                        r += dr
                        c += dc
        return False

    def make_move(self, row, col, player):
        if self.is_valid_move(row, col, player):
            self.board[row][col] = player
            directions = [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (-1, -1), (1, -1), (-1, 1)]
            for dr, dc in directions:
                r, c = row + dr, col + dc
                if 0 <= r < 8 and 0 <= c < 8 and self.board[r][c] != '.' and self.board[r][c] != player:
                    to_flip = []
                    while 0 <= r < 8 and 0 <= c < 8 and self.board[r][c] != '.':
                        if self.board[r][c] == player:
                            for flip_row, flip_col in to_flip:
                                self.board[flip_row][flip_col] = player
                            break
                        to_flip.append((r, c))
                        r += dr
                        c += dc

    def get_winner(self):
        count_player = sum(row.count('B') for row in self.board)
        count_opponent = sum(row.count('W') for row in self.board)
        if count_player > count_opponent:
            return 'Player B'
        elif count_opponent > count_player:
            return 'Player W'
        else:
            return 'It\'s a tie'

def minimax(game, depth, alpha, beta, maximizing_player, player):
    if depth == 0 or not any('.' in row for row in game.board):
        count_player = sum(row.count(player) for row in game.board)
        count_opponent = sum(row.count('B' if player == 'W' else 'W') for row in game.board)
        return count_player - count_opponent

    legal_moves = [(r, c) for r in range(8) for c in range(8) if game.is_valid_move(r, c, player)]

    if maximizing_player:
        max_eval = float('-inf')
        for move in legal_moves:
            new_game = OthelloGame()
            new_game.board = [row[:] for row in game.board]
            new_game.make_move(move[0], move[1], player)
            eval = minimax(new_game, depth - 1, alpha, beta, False, player)
            max_eval = max(max_eval, eval)
            alpha = max(alpha, eval)
            if beta <= alpha:
                break
        return max_eval
    else:
        min_eval = float('inf')
        for move in legal_moves:
            new_game = OthelloGame()
            new_game.board = [row[:] for row in game.board]
            new_game.make_move(move[0], move[1], 'B' if player == 'W' else 'W')
            eval = minimax(new_game, depth - 1, alpha, beta, True, player)
            min_eval = min(min_eval, eval)
            beta = min(beta, eval)
            if beta <= alpha:
                break
        return min_eval

def get_best_move(game, player):
    legal_moves = [(r, c) for r in range(8) for c in range(8) if game.is_valid_move(r, c, player)]
    best_move = None
    best_eval = float('-inf')
    alpha, beta = float('-inf'), float('inf')

    for move in legal_moves:
        new_game = OthelloGame()
        new_game.board = [row[:] for row in game.board]
        new_game.make_move(move[0], move[1], player)
        eval = minimax(new_game, 2, alpha, beta, False, player)  # Adjust the depth as needed

        if eval > best_eval:
            best_eval = eval
            best_move = move

    return best_move

# Main game loop
if __name__ == "__main__":
    game = OthelloGame()

    while True:
        game.display_board()

        player_move = input("Enter your move (row col): ")
        try:
            player_move = tuple(map(int, player_move.split()))
            player_move = (player_move[0] - 1, player_move[1] - 1)  # Adjust indices
            if not game.is_valid_move(player_move[0], player_move[1], 'B'):
                print("Invalid move. Try again.")
                continue
        except (ValueError, IndexError):
            print("Invalid input. Please enter two numbers separated by a space.")

        game.make_move(player_move[0], player_move[1], 'B')
        game.display_board()

        if not any('.' in row for row in game.board):
            print("Game Over!")
            print("Winner: ", game.get_winner())
            break

        opponent_move = get_best_move(game, 'W')
        if opponent_move is not None:
            game.make_move(opponent_move[0], opponent_move[1], 'W')
            game.display_board()

            if not any('.' in row for row in game.board):
                print("Game Over!")
                print("Winner: ", game.get_winner())
                break
        else:
            print("No valid move for player W. Game Over.")
            break
