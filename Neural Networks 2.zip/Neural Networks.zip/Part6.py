import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

def add_noise(data, noise_level):
    noisy_data = data.copy()
    pixel_to_change = np.random.randint(0, data.shape[0]), np.random.randint(0, data.shape[1])  # Randomly select one pixel
    # Modify the color of the selected pixel with a noticeable change
    noisy_data[pixel_to_change] = np.random.uniform(0, noise_level, 3) * 0.7 + 0.3
    return np.clip(noisy_data, 0, 1), pixel_to_change

def denoise_image(noisy_image, pixel_to_change):
    denoised_image = noisy_image.copy()
    noisy_pixel_y, noisy_pixel_x = pixel_to_change
    
    # Apply a simple average filter to denoise the pixel
    denoised_image[noisy_pixel_y, noisy_pixel_x] = np.mean(noisy_image[max(0, noisy_pixel_y-1):noisy_pixel_y+2,
                                                                      max(0, noisy_pixel_x-1):noisy_pixel_x+2], axis=(0, 1))
    return denoised_image

# Generate 5 different examples for testing
num_examples = 5

for i in range(num_examples):
    # Generate random original image with different colors
    original_image = np.random.rand(8, 8, 3)

    # Add noise to the original image (change one pixel)
    noisy_image, pixel_to_change = add_noise(original_image, noise_level=0.1)

    # Denoise the image using a simple method
    denoised_image = denoise_image(noisy_image, pixel_to_change)

    # Display the original, noisy, and denoised images with a red square around the noisy pixel
    fig, ax = plt.subplots(1, 3, figsize=(12, 4))

    ax[0].imshow(original_image)
    ax[0].set_title('Original')

    ax[1].imshow(noisy_image)
    ax[1].set_title('Noisy')
    # Draw a red square around the noisy pixel
    square = patches.Rectangle((pixel_to_change[1] - 0.5, pixel_to_change[0] - 0.5), 1, 1,
                               linewidth=2, edgecolor='red', facecolor='none')
    ax[1].add_patch(square)

    ax[2].imshow(denoised_image)
    ax[2].set_title('Denoised')

    plt.show()
