import numpy as np
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPRegressor

points = []

def on_motion(event):
    if event.inaxes is not None:
        x, y = event.xdata, event.ydata
        points.append((x, y))
        plt.scatter(x, y, c='blue', marker='o', label='Training Data')
        plt.draw()

def on_release(event):
    if event.inaxes is not None:
        x, y = event.xdata, event.ydata
        points.append((x, y))
        plt.scatter(x, y, c='blue', marker='o', label='Training Data')
        plt.draw()

# Create the initial graph
fig, ax = plt.subplots()
plt.title("Draw your shape. Close the plot when finished.")
plt.xlim(-50, 50)
plt.ylim(-50, 50)
cid_motion = fig.canvas.mpl_connect('motion_notify_event', on_motion)
cid_release = fig.canvas.mpl_connect('button_release_event', on_release)

plt.show()

# Once the user closes the graph, continue with MLP prediction
if len(points) > 1:
    points = np.array(points)
    X = points[:, 0].reshape(-1, 1)  # X values
    y = points[:, 1]  # Y values

    # Identify upper points, for example, odd integers
    upper_points = points[points[:, 1] % 2 == 1]

    # Fit an MLP to predict the shape
    mlp = MLPRegressor(hidden_layer_sizes=(100, 100), max_iter=1000, random_state=42)
    mlp.fit(X, y)

    # Resample the X values for better MLP prediction
    x_values_resample = np.linspace(-50, 50, 1000).reshape(-1, 1)

    # Predict points using MLP
    mlp_predictions = mlp.predict(x_values_resample.reshape(-1, 1))

    # Plot the training data, upper points, and MLP prediction
    plt.scatter(points[:, 0], points[:, 1], c='blue', marker='o', label='Training Data')
    plt.scatter(upper_points[:, 0], upper_points[:, 1], c='red', marker='o', s=150, label='Upper Points')
    plt.plot(x_values_resample, mlp_predictions, c='green', label='MLP Prediction')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.legend()
    plt.show()