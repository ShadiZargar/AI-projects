import numpy as np
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPRegressor

class FunctionPlotter:
    def __init__(self):
        self.pi = 2 * np.pi
        self.X_train = [i / 500 for i in range(0, int(500 * self.pi))]
        self.X_train = np.array(self.X_train)
        self.X_train = self.X_train + 1e-10  # positive constant

        self.y_train1 = np.sin(self.X_train)
        self.y_train2 = np.cos(self.X_train)
        self.y_train3 = np.tan(self.X_train)
        self.y_train4 = np.log10(self.X_train)
        self.y_train5 = np.sin(self.X_train) * np.log10(self.X_train)

        # Create an MLP regressor
        self.mlp = MLPRegressor(hidden_layer_sizes=(20, 10), activation='logistic', solver='adam', max_iter=1000,
                                random_state=0)

        # Reshape X_train for training
        self.X_train = self.X_train.reshape(-1, 1)

        # Wider range of input
        self.X_plot = [i + 0.3 / 600 for i in range(0, int(600 * self.pi))]
        self.X_plot = np.array(self.X_train)

    def train_and_predict(self, y_train):
        # Train the MLP on the training data
        self.mlp.fit(self.X_train, y_train)

        # Predictions on the wider range
        y_pred = self.mlp.predict(self.X_plot)

        # Predictions on the test data (use the function itself)
        y_test = y_train

        # Calculate the error rate (MSE) for the test set
        mse_test = ((y_test - self.mlp.predict(self.X_train)) ** 2).mean()

        return y_pred, y_test, mse_test

    def plot_functions(self):
        # Set up subplots
        fig, axes = plt.subplots(5, 2, figsize=(12, 12))

        # Loop through each function
        for i, y_train in enumerate([self.y_train1, self.y_train2, self.y_train3, self.y_train4, self.y_train5]):
            y_pred, y_test, mse_test = self.train_and_predict(y_train)

            # Plotting for training data
            axes[i, 0].plot(self.X_train, y_train, label='Training Data', color='blue')
            axes[i, 0].plot(self.X_plot, y_pred, label=f'MLP Predictions (Function {i + 1})', color='red')
            axes[i, 0].set_title(f'Function {i + 1} - Training Data')
            axes[i, 0].legend()

            # Plotting for test data
            axes[i, 1].plot(self.X_train, y_test, label='Test Data (Function itself)', color='green')
            axes[i, 1].plot(self.X_train, self.mlp.predict(self.X_train), label=f'MLP Predictions (Function {i + 1})',
                            color='red')
            axes[i, 1].set_title(f'Function {i + 1} - Test Data')
            axes[i, 1].legend()

            # Display the error rate (MSE) for the test set
            axes[i, 1].text(0.5, 0.5, f'MSE: {mse_test:.4f}', fontsize=12, ha='center', va='center')

        
        for ax in axes[:, 0]:
            ax.set_xlabel('X')
            ax.set_ylabel('y')

        plt.tight_layout()
        plt.show()

# Create an instance of FunctionPlotter
plotter = FunctionPlotter()

# Call the method to generate and plot functions
plotter.plot_functions()
