import gym
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import pickle

class ModifiedQNetwork(nn.Module):
    def __init__(self, input_dims, fc1_dims, fc2_dims, n_actions):
        super(ModifiedQNetwork, self).__init__()
        self.fc1 = nn.Linear(*input_dims, fc1_dims)
        self.fc2 = nn.Linear(fc1_dims, fc2_dims)
        self.fc3 = nn.Linear(fc2_dims, n_actions)

    def forward(self, state):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        actions = self.fc3(x)
        return actions

class ModifiedDDQNAgent():
    def __init__(self, gamma, epsilon, lr, input_dims, batch_size, n_actions, max_mem_size=100000, eps_end=0.01, eps_dec=5e-4, q_net=None, tgt_net=None):
        self.gamma = gamma
        self.epsilon = epsilon
        self.lr = lr
        self.input_dims = input_dims
        self.action_space = [i for i in range(n_actions)]
        self.max_mem_size = max_mem_size
        self.batch_size = batch_size
        self.mem_counter = 0
        self.eps_end = eps_end
        self.eps_dec = eps_dec

        self.q_network = q_net if q_net else ModifiedQNetwork(input_dims, 256, 256, n_actions)
        self.target_network = tgt_net if tgt_net else ModifiedQNetwork(input_dims, 256, 256, n_actions)
        self.target_network.load_state_dict(self.q_network.state_dict())
        self.target_network.eval()

        self.q_network_optimizer = torch.optim.Adam(self.q_network.parameters(), lr=lr)
        self.loss_function = nn.MSELoss()

        self.memory = {'state': np.zeros((max_mem_size, *input_dims), dtype=np.float32),
                       'action': np.zeros(max_mem_size, dtype=np.int32),
                       'reward': np.zeros(max_mem_size, dtype=np.float32),
                       'new_state': np.zeros((max_mem_size, *input_dims), dtype=np.float32),
                       'done': np.zeros(max_mem_size, dtype=bool)}

    def store_transition(self, state, action, reward, new_state, done):
        index = self.mem_counter % self.max_mem_size
        self.memory['state'][index] = state
        self.memory['action'][index] = action
        self.memory['reward'][index] = reward
        self.memory['new_state'][index] = new_state
        self.memory['done'][index] = done
        self.mem_counter += 1

    def choose_action(self, observation):
        if np.random.random() > self.epsilon:
            state = torch.tensor([observation], dtype=torch.float32)
            actions = self.q_network(state)
            action = torch.argmax(actions).item()
        else:
            action = np.random.choice(self.action_space)
        return action

    def learn(self):
        if self.mem_counter < self.batch_size:
            return

        self.q_network_optimizer.zero_grad()
        max_mem = min(self.mem_counter, self.max_mem_size)
        batch = np.random.choice(max_mem, self.batch_size, replace=False)
        batch_index = np.arange(self.batch_size, dtype=np.int32)

        state_batch = torch.tensor(self.memory['state'][batch], dtype=torch.float32)
        new_state_batch = torch.tensor(self.memory['new_state'][batch], dtype=torch.float32)
        reward_batch = torch.tensor(self.memory['reward'][batch], dtype=torch.float32)
        done_batch = torch.tensor(self.memory['done'][batch], dtype=torch.bool)

        action_batch = self.memory['action'][batch]

        q_eval = self.q_network(state_batch)[batch_index, action_batch]
        q_next = self.target_network(new_state_batch)
        q_next[done_batch] = 0.0

        q_target = reward_batch + self.gamma * torch.max(q_next, dim=1)[0]

        loss = self.loss_function(q_target, q_eval)
        loss.backward()
        self.q_network_optimizer.step()

        self.epsilon = max(self.epsilon - self.eps_dec, self.eps_end)

def train_modified_agent():
    env = gym.make("LunarLander-v2")
    agent = ModifiedDDQNAgent(gamma=0.99, epsilon=1.0, lr=0.003, input_dims=[8], n_actions=4, max_mem_size=1000000, batch_size=64, eps_end=0.01, eps_dec=0.99)

    scores, eps_history = [], []
    n_games = 30

    for episode in range(n_games):
        score = 0
        done = False
        observation, info = env.reset(seed=42)

        while not done:
            action = agent.choose_action(observation)
            observation_, reward, terminated, truncated, info = env.step(action)
            score += reward
            done = terminated or truncated

            agent.store_transition(observation, action, reward, observation_, done)
            agent.learn()

            observation = observation_

        scores.append(score)
        eps_history.append(agent.epsilon)
        avg_score = np.mean(scores[-100:])

        print('Episode', episode, 'Score: %.2f' % score, 'Average Score: %.2f' % avg_score, 'Epsilon: %.2f' % agent.epsilon)

    env.close()

    with open('trained_modified_agent_final.pkl', 'wb') as f:
        pickle.dump((agent.q_network, agent.target_network, agent.epsilon, scores, eps_history), f)

def test_modified_agent():
    env = gym.make("LunarLander-v2", render_mode="shad")  # Ensure render_mode is valid

    with open('trained_modified_agent_final.pkl', 'rb') as f:
        q_network, target_network, epsilon, scores, eps_history = pickle.load(f)
        agent = ModifiedDDQNAgent(gamma=0.99, epsilon=epsilon, lr=0.003, input_dims=[8], n_actions=4, max_mem_size=1000000, batch_size=64, eps_end=0.01, eps_dec=0.99, q_net=q_network, tgt_net=target_network)

        n_games = 500
        scores = []  # Initialize lists correctly
        eps_history = []

        for episode in range(n_games):
            score = 0
            done = False
            observation, info = env.reset(seed=42)

            while not done:
                action = agent.choose_action(observation)
                observation_, reward, terminated, truncated, info = env.step(action)
                score += reward
                done = terminated or truncated

                observation = observation_

            scores.append(score)
            eps_history.append(agent.epsilon)
            avg_score = np.mean(scores[-100:])

            print('Episode', episode, 'Score: %.2f' % score, 'Average Score: %.2f' % avg_score, 'Epsilon: %.2f' % agent.epsilon)

        env.close()

if __name__ == "__main__":
    train_modified_agent()
    test_modified_agent()

