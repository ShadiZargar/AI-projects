import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification
from sklearn.svm import SVC

# Function to generate and plot data
def generate_and_plot_data(n_points, complexity):
    X, y = make_classification(
        n_samples=n_points, 
        n_features=2, 
        n_informative=2, 
        n_redundant=0, 
        n_clusters_per_class=1,
        random_state=42,
        flip_y=0,
        class_sep=complexity
    )

    plt.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.Paired, marker='o')
    plt.title(f'Data with Complexity: {complexity}')
    plt.show()

    return X, y

# Function to train and plot SVM with different colors for margin and separator lines
def train_and_plot_svm(X, y, kernel, C):
    clf = SVC(kernel=kernel, C=C)
    clf.fit(X, y)

    # Plotting
    plt.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.Paired, marker='o')
    
    # Plot the decision function
    ax = plt.gca()
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()
    
    # Create grid to evaluate model
    xx, yy = np.meshgrid(np.linspace(xlim[0], xlim[1], 50),
                         np.linspace(ylim[0], ylim[1], 50))
    
    Z = clf.decision_function(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)
    
    # Plot decision boundary and margins with different colors
    plt.contour(xx, yy, Z, colors=['k', 'k', 'k'], levels=[-1, 0, 1], alpha=0.5,
                linestyles=['--', '-', '--'])
    
    # Plot support vectors
    plt.scatter(clf.support_vectors_[:, 0], clf.support_vectors_[:, 1], s=100,
                linewidth=1, facecolors='none', edgecolors='k')
    
    plt.title(f'SVM with {kernel} Kernel and C={C}')
    
    # Label lines
    plt.text(xlim[0] + 0.1, ylim[1] - 0.1, 'Margin', color='red')
    plt.text(xlim[0] + 0.1, ylim[0] + 0.1, 'Separator', color='blue')
    
    plt.show()

# Generate and plot simple data
X_simple, y_simple = generate_and_plot_data(100, 0.5)

# Train and plot SVM with different kernels and parameters
kernels = ['linear', 'poly', 'rbf', 'sigmoid']
Cs = [0.1, 1, 10, 100]

for kernel in kernels:
    for C in Cs:
        train_and_plot_svm(X_simple, y_simple, kernel, C)