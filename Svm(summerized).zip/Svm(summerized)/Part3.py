import os
import cv2
import numpy as np
from tqdm import tqdm
from sklearn import svm
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.decomposition import PCA

# Function to load images from a folder with tqdm progress bar and error handling
def load_images_with_progress(folder, num_images=None):
    images = []
    labels = []
    for category in tqdm(os.listdir(folder), desc="Loading images", unit="category"):
        category_path = os.path.join(folder, category)
        if os.path.isdir(category_path):
            for filename in tqdm(os.listdir(category_path)[:num_images], desc=f"Category: {category}", unit="image"):
                img_path = os.path.join(category_path, filename)
                try:
                    img = cv2.imread(img_path)
                    if img is None:
                        print(f"Warning: Could not load image: {img_path}")
                        continue

                    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
                    img = cv2.resize(img, (64, 64))  # Resize to a consistent size
                    images.append(img.flatten())  # Flatten the image array
                    labels.append(category.strip())  # Remove leading and trailing whitespaces
                except Exception as e:
                    print(f"Error processing image: {img_path}, Error: {e}")
        else:
            # Load images directly from the main folder without subfolders
            img_path = os.path.join(folder, category)
            try:
                img = cv2.imread(img_path)
                if img is None:
                    print(f"Warning: Could not load image: {img_path}")
                    continue

                img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
                img = cv2.resize(img, (64, 64))  # Resize to a consistent size
                images.append(img.flatten())  # Flatten the image array
                labels.append(category.strip())  # Remove leading and trailing whitespaces
            except Exception as e:
                print(f"Error processing image: {img_path}, Error: {e}")

    return np.array(images), np.array(labels)

# Load a limited number of images from the "train" folder with tqdm progress bar
train_images, train_labels = load_images_with_progress('/Users/shadizargarzadeh/Desktop/AIProject/SVM/Part3/train', num_images=100)

# Load a limited number of additional images from the "images" folder for training with tqdm progress bar
additional_images, additional_labels = load_images_with_progress('/Users/shadizargarzadeh/Desktop/AIProject/SVM/Part3/images', num_images=100)

# Ensure all images have the same dimensions by resizing
additional_images_resized = []
for img in tqdm(additional_images, desc="Resizing images", unit="image"):
    img_resized = cv2.resize(img.reshape(64, 64), (64, 64))
    additional_images_resized.append(img_resized.flatten())

# Combine the training data
X_train = np.concatenate((train_images, additional_images_resized), axis=0)
y_train = np.concatenate((train_labels, additional_labels), axis=0)

# Load a limited number of images from the "test" folder with tqdm progress bar
test_images, test_labels = load_images_with_progress('/Users/shadizargarzadeh/Desktop/AIProject/SVM/Part3/test', num_images=50)

# Check if test_images is not empty before proceeding
if len(test_images) == 0:
    print("Error: No test images loaded. Please check your test data.")
else:
    # Encode labels
    label_encoder = LabelEncoder()
    train_labels_encoded = label_encoder.fit_transform(y_train)
    
    # Ensure test_labels have no leading or trailing whitespaces before encoding
    test_labels_stripped = [label.strip() for label in test_labels]
    
    # Handle unseen labels during test phase
    try:
        test_labels_encoded = label_encoder.transform(test_labels_stripped)
    except ValueError as e:
        print(f"Warning: {e}")
        print("Unseen labels during test phase. Adjusting label encoding accordingly.")
        
        # Find the unseen labels
        unseen_labels = set(test_labels_stripped) - set(label_encoder.classes_)

        # Add unseen labels to the label_encoder.classes_
        label_encoder.classes_ = np.concatenate((label_encoder.classes_, list(unseen_labels)))

        # Encode the test labels again
        test_labels_encoded = label_encoder.transform(test_labels_stripped)

    # Standardize the data
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    
    # Ensure test_images is a 2D array before transforming
    if test_images.ndim == 1:
        test_images = test_images.reshape(-1, 1)

    X_test_scaled = scaler.transform(test_images)

    # Apply PCA for dimensionality reduction
    pca = PCA(n_components=100)  # Adjust the number of components based on your data
    X_train_pca = pca.fit_transform(X_train_scaled)
    X_test_pca = pca.transform(X_test_scaled)

    # Hyperparameter tuning using Grid Search
    param_grid = {'C': [0.1, 1, 10], 'gamma': [0.01, 0.1, 1]}
    grid_search = GridSearchCV(svm.SVC(kernel='rbf'), param_grid, cv=3)
    grid_search.fit(X_train_pca, train_labels_encoded)

    # Get the best parameters
    best_params = grid_search.best_params_
    print("Best Parameters:", best_params)

    # Create SVM model with the best parameters
    clf = svm.SVC(kernel='rbf', C=best_params['C'], gamma=best_params['gamma'])
    clf.fit(X_train_pca, train_labels_encoded)

    # Make predictions
    predictions = clf.predict(X_test_pca)

    # Evaluate accuracy and print classification report
    accuracy = accuracy_score(test_labels_encoded, predictions)
    print(f"Accuracy: {accuracy}")
    print("Classification Report:\n", classification_report(test_labels_encoded, predictions))
