import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier  # Import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.datasets import fetch_openml

# Load USPS dataset
usps = fetch_openml('usps', version=2)
X_usps, y_usps = usps.data / 255.0, usps.target.astype(int)

# Split the data into training and testing sets
X_usps_train, X_usps_test, y_usps_train, y_usps_test = train_test_split(X_usps, y_usps, test_size=0.2, random_state=42)

# Normalize the data
scaler_usps = StandardScaler()
X_usps_train = scaler_usps.fit_transform(X_usps_train)
X_usps_test = scaler_usps.transform(X_usps_test)

# SVM classification
svm = SVC(kernel='rbf', C=1.0, gamma='scale')  # You can adjust kernel and other parameters
svm.fit(X_usps_train, y_usps_train)
y_usps_pred_svm = svm.predict(X_usps_test)

# Neural Network (Using corrected import)
mlp = MLPClassifier(hidden_layer_sizes=(128,), max_iter=5, alpha=1e-4, solver='sgd',
                    verbose=10, random_state=1, learning_rate_init=.1)

mlp.fit(X_usps_train, y_usps_train)  # Use the USPS data for training
y_usps_pred_nn = mlp.predict(X_usps_test)

# Evaluate the accuracy of SVM and Neural Network
accuracy_svm = accuracy_score(y_usps_test, y_usps_pred_svm)
accuracy_nn = accuracy_score(y_usps_test, y_usps_pred_nn)

print(f'SVM Test accuracy on USPS dataset: {accuracy_svm}')
print(f'Neural Network Test accuracy on USPS dataset: {accuracy_nn}')
